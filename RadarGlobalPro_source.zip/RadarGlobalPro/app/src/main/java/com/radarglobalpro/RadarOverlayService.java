package com.radarglobalpro;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.Locale;

public class RadarOverlayService extends Service {
    public static final String ACTION_SHOW = "com.radarglobalpro.SHOW";
    private static final int PLACE_ID = 107778070777162;
    private WindowManager wm;
    private View panel;
    private LinearLayout rows;
    private TextView status;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean refreshing = false;
    private final Runnable refreshTask = new Runnable() {
        @Override public void run() {
            fetchServers();
            handler.postDelayed(this, 30000);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createNotification();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_SHOW.equals(intent.getAction())) showOverlay();
        return START_STICKY;
    }

    private void createNotification() {
        String channel = "radar_overlay";
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(channel, "Radar flotante", NotificationManager.IMPORTANCE_LOW));
        }
        Notification n = new Notification.Builder(this, channel)
            .setContentTitle("Radar Global Pro activo")
            .setContentText("Buscando servidores públicos de Roblox")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build();
        startForeground(7, n);
    }

    private void showOverlay() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        if (panel != null) return;
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(12, 10, 12, 10);
        shell.setBackgroundColor(Color.rgb(5, 13, 8));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(Color.rgb(0, 45, 18));
        TextView heading = text("RADAR GLOBAL  •  STEAL AN EGG", 16, 0xFF39FF14, true);
        header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = text("✕", 22, Color.WHITE, true);
        close.setPadding(14, 4, 10, 4);
        header.addView(close);
        shell.addView(header);

        LinearLayout controls = new LinearLayout(this);
        Button reload = button("ACTUALIZAR");
        Button hide = button("MINIMIZAR");
        controls.addView(reload, new LinearLayout.LayoutParams(0, -2, 1));
        controls.addView(hide, new LinearLayout.LayoutParams(0, -2, 1));
        shell.addView(controls);

        status = text("Conectando con Roblox...", 12, 0xFFB9D6C1, false);
        shell.addView(status);

        ScrollView scroll = new ScrollView(this);
        rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows);
        shell.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView foot = text("Servidores públicos • datos de Roblox • actualización cada 30 s", 10, 0xFF7EAB8A, false);
        shell.addView(foot);

        close.setOnClickListener(v -> stopSelf());
        reload.setOnClickListener(v -> fetchServers());
        hide.setOnClickListener(v -> {
            if (panel != null) { wm.removeView(panel); panel = null; stopSelf(); }
        });

        // Drag from header
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            (int)(getResources().getDisplayMetrics().widthPixels * 0.92),
            (int)(getResources().getDisplayMetrics().heightPixels * 0.72),
            Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = 70;
        header.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY; float downX, downY;
            public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = lp.x; startY = lp.y; downX = e.getRawX(); downY = e.getRawY(); return true;
                } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.x = startX + (int)(e.getRawX() - downX);
                    lp.y = startY + (int)(e.getRawY() - downY);
                    wm.updateViewLayout(panel, lp); return true;
                }
                return false;
            }
        });

        panel = shell;
        wm.addView(panel, lp);
        fetchServers();
        handler.postDelayed(refreshTask, 30000);
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(8, 8, 8, 8);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.BLACK);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF39FF14));
        return b;
    }

    private void fetchServers() {
        if (refreshing || rows == null) return;
        refreshing = true;
        status.setText("Buscando servidores públicos...");
        new Thread(() -> {
            String result = null, error = null;
            try {
                URL url = new URL("https://games.roblox.com/v1/games/" + PLACE_ID +
                    "/servers/Public?sortOrder=Desc&excludeFullGames=true&limit=100");
                HttpURLConnection c = (HttpURLConnection)url.openConnection();
                c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(12000);
                c.setRequestProperty("Accept", "application/json");
                int code = c.getResponseCode();
                InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close(); c.disconnect();
                if (code != 200) throw new Exception("Roblox respondió HTTP " + code);
                result = out.toString("UTF-8");
            } catch (Exception ex) { error = ex.getMessage(); }
            final String json = result, err = error;
            handler.post(() -> {
                refreshing = false;
                if (rows == null || status == null) return;
                if (err != null) { status.setText("No se pudo consultar Roblox: " + err); return; }
                try {
                    JSONObject root = new JSONObject(json);
                    JSONArray data = root.optJSONArray("data");
                    rows.removeAllViews();
                    if (data == null || data.length() == 0) {
                        status.setText("No hay servidores disponibles en esta respuesta."); return;
                    }
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject s = data.getJSONObject(i);
                        String id = s.optString("id", "");
                        int playing = s.optInt("playing", 0), max = s.optInt("maxPlayers", 0);
                        int ping = s.optInt("ping", -1), fps = s.optInt("fps", -1);
                        addServerRow(id, playing, max, ping, fps);
                    }
                    status.setText("Servidores mostrados: " + data.length() + " • lista pública mundial (sin filtro geográfico)");
                } catch (Exception ex) { status.setText("Respuesta inesperada de Roblox."); }
            });
        }).start();
    }

    private void addServerRow(String id, int playing, int max, int ping, int fps) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(10, 8, 10, 8);
        card.setBackgroundColor(0xFF14241A);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 5, 0, 5);
        rows.addView(card, cp);

        TextView details = text("SERVIDOR PÚBLICO   •   " + playing + "/" + max +
            " jugadores\nPing: " + (ping < 0 ? "N/D" : ping + " ms") +
            "   •   FPS: " + (fps < 0 ? "N/D" : fps), 13, Color.WHITE, true);
        card.addView(details);
        LinearLayout actions = new LinearLayout(this);
        TextView idText = text("ID: " + (id.length() > 13 ? id.substring(0, 13) + "…" : id), 10, 0xFF9AB5A0, false);
        actions.addView(idText, new LinearLayout.LayoutParams(0, -2, 1));
        Button join = button("ENTRAR");
        actions.addView(join);
        card.addView(actions);
        join.setOnClickListener(v -> {
            try {
                Uri uri = Uri.parse("roblox://experiences/start?placeId=" + PLACE_ID + "&gameInstanceId=" + Uri.encode(id));
                Intent open = new Intent(Intent.ACTION_VIEW, uri);
                open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(open);
            } catch (Exception e) {
                Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.roblox.com/games/" + PLACE_ID));
                web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(web);
            }
        });
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(refreshTask);
        if (wm != null && panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} }
        panel = null; rows = null;
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
