package com.radarglobalpro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 4101;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(32, 48, 32, 32);
        page.setBackgroundColor(0xFF07110B);

        TextView title = new TextView(this);
        title.setText("RADAR GLOBAL PRO\nSTEAL AN EGG");
        title.setTextColor(0xFF39FF14);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 24);
        page.addView(title);

        TextView info = new TextView(this);
        info.setText("Buscador de servidores públicos de Roblox.\n\nEl radar muestra jugadores conectados, capacidad, ping y FPS cuando Roblox publica esos datos. No puede leer qué huevos o multiplicadores hay dentro de cada partida.");
        info.setTextColor(0xFFFFFFFF);
        info.setTextSize(16);
        info.setPadding(0, 0, 0, 28);
        page.addView(info);

        Button start = new Button(this);
        start.setText("ACTIVAR VENTANA FLOTANTE");
        page.addView(start);
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(permission, OVERLAY_REQUEST);
            } else {
                startRadar();
            }
        });

        TextView note = new TextView(this);
        note.setText("\nDespués de conceder el permiso, vuelve aquí y pulsa ACTIVAR. Luego abre Roblox. Puedes cerrar el radar desde su botón X.");
        note.setTextColor(0xFFB9C9BE);
        note.setTextSize(14);
        page.addView(note);
        setContentView(page);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && Settings.canDrawOverlays(this)) startRadar();
    }

    private void startRadar() {
        Intent service = new Intent(this, RadarOverlayService.class);
        service.setAction(RadarOverlayService.ACTION_SHOW);
        startForegroundService(service);
        finish();
    }
}
