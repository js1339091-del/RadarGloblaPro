RADAR GLOBAL PRO - STEAL AN EGG
Proyecto Android inicial para Samsung S22 Ultra.

QUÉ HACE ESTA VERSIÓN
- Solicita permiso Android para mostrar una ventana flotante.
- Consulta la lista pública de servidores Roblox para Place ID 107778070777162.
- Muestra jugadores/capacidad, ping y FPS cuando Roblox devuelve esos campos.
- Actualiza cada 30 segundos.
- Incluye botón para intentar abrir el servidor seleccionado.

LIMITACIONES IMPORTANTES
- La lista de Roblox no indica necesariamente país/región del servidor.
- La API pública no revela los huevos, multiplicadores ni botín dentro de cada servidor.
- Por eso esta versión NO filtra huevos grandes ni inventa multiplicadores.
- El botón ENTRAR usa un deep link de Roblox; Roblox puede rechazar la unión o abrir solo la página del juego.
- La API pública puede aplicar límites o cambiar su comportamiento.
- La ventana flotante requiere que el usuario conceda manualmente el permiso "Mostrar sobre otras aplicaciones".
- No solicita contraseña, cookie ni credenciales de Roblox.

CÓMO GENERAR EL APK SIN PC (requiere cuenta GitHub)
1. Crea un repositorio nuevo en GitHub desde Chrome en el teléfono.
2. Sube todos los archivos de este proyecto conservando las carpetas.
3. Abre la pestaña Actions y ejecuta el workflow "Build APK".
4. Cuando termine, entra al workflow y descarga el artefacto "RadarGlobalPro-debug-apk".
5. Descomprime el ZIP y abre app-debug.apk en el S22 Ultra.
6. Android pedirá confirmar la instalación desde esa fuente.
7. Abre Radar Global Pro, pulsa ACTIVAR VENTANA FLOTANTE y concede el permiso.
8. Vuelve a la app, activa el radar y después abre Roblox.

El APK debug es para pruebas. No está firmado para distribución pública.
